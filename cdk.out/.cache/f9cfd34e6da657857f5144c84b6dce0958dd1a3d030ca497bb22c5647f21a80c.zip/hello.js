exports.handler = async function(event){
    console.log("request", JSON.stringify(evemt, undefined, 2));
    return {
        statusCode:200,
        headhers: {"Content-Type": "text/plain"},
        body: `Hello, CDK! You've hit ${event.path}\n`
    };
}