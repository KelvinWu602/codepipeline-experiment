exports.handler = async function(event){
    console.log("request", JSON.stringify(event, undefined, 2));
    return {
        statusCode:200,
        headhers: {"Content-Type": "text/plain"},
        body: `Good Night Night, CDK! You've hit ${event.path}\n`
    };
}