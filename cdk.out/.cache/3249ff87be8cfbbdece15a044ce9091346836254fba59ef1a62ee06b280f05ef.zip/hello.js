exports.handler = async function(event){
    console.log("request", JSON.stringify(evemt, undefined, 2));
    return {
        statusCode:200,
        headhers: {"Content-Type": "text/plain"},
        body: `Good Afternoon, CDK! You've hit ${event.path}\n`
    };
}